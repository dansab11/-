package courseWorkDimash.electonicShop.web;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import courseWorkDimash.electonicShop.dao.CategoryDao;
import courseWorkDimash.electonicShop.dao.CountryDao;
import courseWorkDimash.electonicShop.dao.LoginDao;
import courseWorkDimash.electonicShop.models.Category;
import courseWorkDimash.electonicShop.models.Country;
import courseWorkDimash.electonicShop.models.LoginBean;
import courseWorkDimash.electonicShop.models.Order;
import courseWorkDimash.electonicShop.models.OrderDetail;
import courseWorkDimash.electonicShop.models.Product;
import courseWorkDimash.electonicShop.models.User;
import courseWorkDimash.electronicShop.utils.JDBCUtils;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private LoginDao loginDao;
	private CountryDao countryDao;
	private CategoryDao categoryDao;

	public LoginServlet() {
		loginDao = new LoginDao();
		countryDao = new CountryDao();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.sendRedirect("login/login-form.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		LoginBean loginBean = new LoginBean(username, password);
		try {
			RequestDispatcher rd;
			if (loginDao.validate(loginBean)) {
				if (loginDao.checkIfAdmin(loginBean)) {
					List<Country> countries = countryDao.selectCountries();
					List<Category> categories = new ArrayList<>();
					List<Product> products = new ArrayList<>();
					List<Order> orders = new ArrayList<>();
					try (Connection conn = JDBCUtils.getConnection();
							PreparedStatement ps = conn.prepareStatement("select o.id,o.`user`,o.orderdate,"
									+ "(select sum(price) from orderdetails where orderid=o.id), "
									+ "u.username,u.`password`," + "u.address,u.phone,u.birthday,u.country,u.isAdmin "
									+ "from orders o join users u on o.`user`=u.id");) {
						ResultSet rs = ps.executeQuery();
						while (rs.next()) {
							User user = new User(rs.getInt(2), rs.getString(5), rs.getString(6), rs.getString(7),
									rs.getString(8), rs.getDate(9).toLocalDate(), rs.getInt(10), rs.getBoolean(11));
							Order order = new Order(rs.getInt(1), rs.getInt(2), rs.getDate(3).toLocalDate(),
									rs.getDouble(4), user);
							orders.add(order);
						}

					}
					try (Connection conn = JDBCUtils.getConnection();
							PreparedStatement ps = conn
									.prepareStatement("SELECT p.id,p.`name`," + "p.description,p.price,p.image,"
											+ "p.units,p.country,p.category,c.`name`,ct.`name`"
											+ " FROM Products p join Categories c " + "on c.id=p.category "
											+ "join Countries ct on ct.id=p.country");) {
						ResultSet rs = ps.executeQuery();
						while (rs.next()) {

							products.add(new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4),
									rs.getString(5), rs.getInt(6), rs.getInt(7), rs.getInt(8),
									new Category(rs.getInt(7), rs.getString(9)),
									new Country(rs.getInt(7), rs.getString(10))));
						}
						rs.close();
					}
					try (Connection conn = JDBCUtils.getConnection();
							PreparedStatement ps = conn.prepareStatement("SELECT * FROM Categories;");) {
						ResultSet rs = ps.executeQuery();
						while (rs.next()) {
							categories.add(new Category(rs.getInt(1), rs.getString(2)));
						}
						rs.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					List<OrderDetail> orderDetails = new ArrayList<OrderDetail>();
					try (Connection conn = JDBCUtils.getConnection();) {
						PreparedStatement ps = conn.prepareStatement("SELECT od.id, od.orderid,od.product, "
								+ "od.amount,od.price,p.`name` FROM OrderDetails od JOIN Products p on p.id=od.product");
						ResultSet rs = ps.executeQuery();
						while (rs.next())
							orderDetails.add(new OrderDetail(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4),
									rs.getDouble(5), new Product(rs.getInt(3), rs.getString(6))));
					}
					request.setAttribute("products", products);
					request.setAttribute("countries", countries);
					request.setAttribute("categoriss", categories);
					request.setAttribute("orders", orders);
					request.setAttribute("orderDetails", orderDetails);
					rd = request.getRequestDispatcher("admin/admin.jsp");
				} else {
					rd = request.getRequestDispatcher("onlineShop/onlineShop.jsp");
					List<Product> products = new ArrayList<>();
					List<Category> categories = new ArrayList<>();
					try (Connection conn = JDBCUtils.getConnection();
							PreparedStatement ps = conn
									.prepareStatement("SELECT p.id,p.`name`," + "p.description,p.price,p.image,"
											+ "p.units,p.country,p.category,c.`name`,ct.`name`"
											+ " FROM Products p join Categories c " + "on c.id=p.category "
											+ "join Countries ct on ct.id=p.country");) {
						ResultSet rs = ps.executeQuery();
						while (rs.next()) {

							products.add(new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4),
									rs.getString(5), rs.getInt(6), rs.getInt(7), rs.getInt(8),
									new Category(rs.getInt(7), rs.getString(9)),
									new Country(rs.getInt(7), rs.getString(10))));
						}
						rs.close();
					}
					int userId = 0;
					try (Connection conn = JDBCUtils.getConnection();
							PreparedStatement ps = conn.prepareStatement("SELECT * FROM Categories;");) {
						ResultSet rs = ps.executeQuery();
						while (rs.next()) {
							categories.add(new Category(rs.getInt(1), rs.getString(2)));
						}
						rs.close();
						PreparedStatement ps1 = conn.prepareStatement("select id from users where username=?");
						ps1.setString(1, loginBean.getUsername());
						rs = ps1.executeQuery();
						if (rs.next()) {
							userId = rs.getInt(1);
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					request.setAttribute("countries", countryDao.selectCountries());
					request.setAttribute("categories", categories);
					request.setAttribute("products", products);
					request.setAttribute("userId", userId);
				}

				rd.forward(request, response);
			} else {
				rd = request.getRequestDispatcher("login/login-form.jsp");
				String notification = "Login failed";
				request.setAttribute("notificationColor", "red");
				request.setAttribute("notification", notification);
				rd.forward(request, response);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
