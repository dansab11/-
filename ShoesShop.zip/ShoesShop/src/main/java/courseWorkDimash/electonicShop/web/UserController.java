package courseWorkDimash.electonicShop.web;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import courseWorkDimash.electonicShop.dao.CountryDao;
import courseWorkDimash.electonicShop.dao.UserDao;
import courseWorkDimash.electonicShop.models.User;

@WebServlet("/register")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserDao userDao;
	private CountryDao countryDao;

	public UserController() {
		userDao = new UserDao();
		countryDao = new CountryDao();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			request.setAttribute("countries", countryDao.selectCountries());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher rd = request.getRequestDispatcher("register/register.jsp");
		rd.forward(request, response);
		// response.sendRedirect("register/register.jsp");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		LocalDate birthday = LocalDate.parse(request.getParameter("birthday"));
		int country = Integer.parseInt(request.getParameter("country"));
		User user = new User(username, password, address, phone, birthday, country, false);
		int res = 0;
		try {
			res = userDao.register(user);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String notificationColor = "red";
		String notification = "user register failed";
		if (res == 1) {
			notification = "user register is successfully";
			notificationColor = "green";
		}
		RequestDispatcher rd = request.getRequestDispatcher("login/login-form.jsp");
		request.setAttribute("notificationColor", notificationColor);
		request.setAttribute("notification", notification);
		rd.forward(request, response);
	}

}
