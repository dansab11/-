package courseWorkDimash.electonicShop.web;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.collections4.IterableUtils;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import courseWorkDimash.electonicShop.dao.CategoryDao;
import courseWorkDimash.electonicShop.dao.CountryDao;
import courseWorkDimash.electonicShop.models.Category;
import courseWorkDimash.electonicShop.models.Country;
import courseWorkDimash.electonicShop.models.Order;
import courseWorkDimash.electonicShop.models.OrderDetail;
import courseWorkDimash.electonicShop.models.Product;
import courseWorkDimash.electonicShop.models.ShoppingCart;
import courseWorkDimash.electonicShop.models.ShoppingCartDetail;
import courseWorkDimash.electonicShop.models.User;
import courseWorkDimash.electronicShop.utils.JDBCUtils;
import org.apache.commons.collections4.CollectionUtils;

@WebServlet("/")
public class crudController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CountryDao countryDao;
	private CategoryDao categoryDao;

	public crudController() {
		countryDao = new CountryDao();
		categoryDao = new CategoryDao();
	}

	private void showEditCountryForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("country/country-form.jsp");
		int countryId = Integer.parseInt(request.getParameter("id"));
		Country country = countryDao.selectCountry(countryId);
		request.setAttribute("country", country);
		rd.forward(request, response);
	}

	private void showNewCountryForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("country/country-form.jsp");
		rd.forward(request, response);
	}

	private void showNewOrderForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("order/order-form.jsp");
		List<User> userList = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("select id,username from users");
			ResultSet rs = ps.executeQuery();
			while (rs.next())
				userList.add(new User(rs.getInt(1), rs.getString(2)));
		}
		request.setAttribute("userList", userList);
		rd.forward(request, response);
	}

	private void showEditOrderForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("order/order-form.jsp");
		Order order = null;
		List<User> userList = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("select id, `user`, orderDate from orders where id=?");
			ps.setInt(1, Integer.parseInt(request.getParameter("id")));
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				order = new Order(rs.getInt(1), rs.getInt(2), rs.getDate(3).toLocalDate());
			}
			rs.close();
			ps = conn.prepareStatement("select id,username from users");
			rs = ps.executeQuery();
			while (rs.next())
				userList.add(new User(rs.getInt(1), rs.getString(2)));
		}
		request.setAttribute("userList", userList);
		request.setAttribute("order", order);
		rd.forward(request, response);
	}

	private void updateOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int userId = Integer.parseInt(request.getParameter("user"));
		LocalDate date = LocalDate.parse(request.getParameter("orderDate"));
		int orderId = Integer.parseInt(request.getParameter("id"));
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("update orders set `user`=?, orderDate=? where id=?");
			ps.setInt(1, userId);
			ps.setDate(2, java.sql.Date.valueOf(date));
			ps.setInt(3, orderId);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
		;
	}

	private void insertOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int userId = Integer.parseInt(request.getParameter("user"));
		LocalDate date = LocalDate.parse(request.getParameter("orderDate"));
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("insert into orders(`user`,orderDate) values (?,?)");
			ps.setInt(1, userId);
			ps.setDate(2, java.sql.Date.valueOf(date));
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
		;
	}

	private void deleteOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int orderId = Integer.parseInt(request.getParameter("id"));
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("delete from orders where id=?");
			ps.setInt(1, orderId);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
		;
	}

	private void adminPanelList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		List<Country> countries = countryDao.selectCountries();
		List<Category> categories = new ArrayList<>();
		List<Product> products = new ArrayList<>();
		List<Order> orders = new ArrayList<>();
		List<OrderDetail> orderDetails = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("SELECT od.id, od.orderid,od.product, "
					+ "od.amount,od.price,p.`name` FROM OrderDetails od JOIN Products p on p.id=od.product");
			ResultSet rs = ps.executeQuery();
			while (rs.next())
				orderDetails.add(new OrderDetail(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4),
						rs.getDouble(5), new Product(rs.getInt(3), rs.getString(6))));
		}
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select o.id,o.`user`,o.orderdate,"
						+ "(select sum(price) from orderdetails where orderid=o.id), " + "u.username,u.`password`,"
						+ "u.address,u.phone,u.birthday,u.country,u.isAdmin "
						+ "from orders o join users u on o.`user`=u.id");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User user = new User(rs.getInt(2), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),
						rs.getDate(9).toLocalDate(), rs.getInt(10), rs.getBoolean(11));
				Order order = new Order(rs.getInt(1), rs.getInt(2), rs.getDate(3).toLocalDate(), rs.getDouble(4), user);
				orders.add(order);
			}

		}
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT p.id,p.`name`," + "p.description,p.price,p.image,"
						+ "p.units,p.country,p.category,c.`name`,ct.`name`" + " FROM Products p join Categories c "
						+ "on c.id=p.category " + "join Countries ct on ct.id=p.country");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {

				products.add(new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4),
						rs.getString(5), rs.getInt(6), rs.getInt(7), rs.getInt(8),
						new Category(rs.getInt(7), rs.getString(9)), new Country(rs.getInt(7), rs.getString(10))));
			}
			rs.close();
		}
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM Categories;");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				categories.add(new Category(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("categoriss", categories);
		request.setAttribute("countries", countries);
		request.setAttribute("products", products);
		request.setAttribute("orders", orders);
		request.setAttribute("orderDetails", orderDetails);
		RequestDispatcher rd = request.getRequestDispatcher("admin/admin.jsp");
		rd.forward(request, response);
	}

	private void insertCountry(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		Country country = new Country(name);
		countryDao.insertCountry(country);
		response.sendRedirect("adminPanel");
	}

	private void updateCountry(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		int id = Integer.parseInt(request.getParameter("id"));
		Country country = new Country(id, name);
		countryDao.updateCountry(country);
		response.sendRedirect("adminPanel");
	}

	private void deleteCountry(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		countryDao.deleteCountry(id);
		response.sendRedirect("adminPanel");
	}

	private void showNewCategoryForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("category/category-form.jsp");
		rd.forward(request, response);
	}

	class Sortbyprice implements Comparator<Product> {

		@Override
		public int compare(Product o1, Product o2) {
			// TODO Auto-generated method stub
			double first = o1.getPrice();
			double second = o2.getPrice();
			if (Math.abs(first - second) < 1E-6) {
				return 0;
			} else {
				return Double.compare(first, second);
			}
		}

	}

	class Sortbyname implements Comparator<Product> {

		@Override
		public int compare(Product o1, Product o2) {
			// TODO Auto-generated method stub
			return o1.getName().compareTo(o2.getName());
		}

	}

	private void listProducts(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("onlineShop/onlineShop.jsp");

		try {
			int userId = Integer.parseInt(request.getParameter("userId"));
			request.setAttribute("userId", userId);
		} catch (Exception ex) {

		}
		List<Product> products = new ArrayList<>();
		List<Category> categories = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT p.id,p.`name`," + "p.description,p.price,p.image,"
						+ "p.units,p.country,p.category,c.`name`,ct.`name`" + " FROM Products p join Categories c "
						+ "on c.id=p.category " + "join Countries ct on ct.id=p.country");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				products.add(new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4),
						rs.getString(5), rs.getInt(6), rs.getInt(7), rs.getInt(8),
						new Category(rs.getInt(7), rs.getString(9)), new Country(rs.getInt(7), rs.getString(10))));
			}
			rs.close();
		}
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM Categories;");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				categories.add(new Category(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("categories", categories);
		if (request.getParameter("sort") != null) {
			try {
				String sort = request.getParameter("sort");
				if ("sortbyprice".equals(sort)) {
					Collections.sort(products, new Sortbyprice());
				} else if ("sortbyname".equals(sort)) {
					Collections.sort(products, new Sortbyname());
				}
				request.setAttribute("sort", sort);
			} catch (Exception e) {

			}
		}
		if (request.getParameter("name") != null) {
			try {
				String filter = request.getParameter("name").trim();
				CollectionUtils.filter(products, p -> p.getName().contains(filter));
				request.setAttribute("name", filter);
			} catch (Exception e) {

			}
		}
		if (request.getParameter("country") != null) {
			try {
				int country = Integer.parseInt(request.getParameter("country"));
				if (country != 0) {
					CollectionUtils.filter(products, p -> p.getCountryId() == country);
					request.setAttribute("country", country);
				} else
					request.setAttribute("country", 0);
			} catch (Exception e) {

			}
		}
		if (request.getParameter("category") != null) {
			try {
				int category = Integer.parseInt(request.getParameter("category"));
				if (category != 0) {
					CollectionUtils.filter(products, p -> p.getCategoryId() == category);
					request.setAttribute("category", category);
				} else
					request.setAttribute("category", 0);
			} catch (Exception e) {

			}
		}
		request.setAttribute("products", products);
		request.setAttribute("countries", countryDao.selectCountries());
		rd.forward(request, response);
	}

	private void showEditCategoryForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		Category category = null;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select * from categories where id=?");) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				category = new Category(rs.getInt(1), rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("category", category);
		RequestDispatcher rd = request.getRequestDispatcher("category/category-form.jsp");
		rd.forward(request, response);
	}

	private void showUserShoppingCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("shoppingCart.jsp");
		int userId = Integer.parseInt(request.getParameter("userId"));
		int cart = 0;
		List<ShoppingCartDetail> shopCartDetails = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select id from shoppingCarts where `user`=?");) {
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				cart = rs.getInt(1);
			} else {
				PreparedStatement ps1 = conn
						.prepareStatement("insert into shoppingCarts(`user`,createdDate) values(?,?)");
				java.sql.Date createdDate = java.sql.Date.valueOf(LocalDate.now());
				ps1.setInt(1, userId);
				ps1.setDate(2, createdDate);
				ps1.executeUpdate();
				ps1.clearParameters();
				ps1 = conn.prepareStatement("select id from shoppingCarts where `user`=?");
				ps1.setInt(1, userId);
				rs = ps1.executeQuery();
				if (rs.next())
					cart = rs.getInt(1);
			}
		}
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn
					.prepareStatement("SELECT scd.id,scd.shoppingCart,scd.product,scd.amount,scd.price, p.`name`,"
							+ "p.description,p.price,p.image,p.units,p.country,p.category "
							+ "FROM ShoppingCartDetails scd JOIN Products p on "
							+ "p.id=scd.product where ShoppingCart = ?");
			ps.setInt(1, cart);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product p = new Product(rs.getInt(3), rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getString(9), rs.getInt(10), rs.getInt(11), rs.getInt(12));
				ShoppingCartDetail d = new ShoppingCartDetail(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), p,
						rs.getDouble(5));
				shopCartDetails.add(d);
			}

		}
		request.setAttribute("userId", userId);
		request.setAttribute("cartid", cart);
		request.setAttribute("userShopCartList", shopCartDetails);

		rd.forward(request, response);
	}

	private void addToShoppingCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("product/buy.jsp");
		int product = Integer.parseInt(request.getParameter("prodId"));
		int userId = Integer.parseInt(request.getParameter("userId"));
		int cart = 0;
		// ��������� ��� ������� �������
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select id from shoppingCarts where `user`=?");) {
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				cart = rs.getInt(1);
			} else {
				PreparedStatement ps1 = conn
						.prepareStatement("insert into shoppingCarts(`user`,createdDate) values(?,?)");
				java.sql.Date createdDate = java.sql.Date.valueOf(LocalDate.now());
				ps1.setInt(1, userId);
				ps1.setDate(2, createdDate);
				ps1.executeUpdate();
				ps1.clearParameters();
				ps1 = conn.prepareStatement("select id from shoppingCarts where `user`=?");
				ps1.setInt(1, userId);
				rs = ps1.executeQuery();
				if (rs.next())
					cart = rs.getInt(1);
			}
		}
		// shoppingCartId
		Product pr = null;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select * from products where id=?");) {
			ps.setInt(1, product);
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				pr = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8));
			rs.close();

		}

		request.setAttribute("shoppingCartId", cart);
		request.setAttribute("product", pr);
		request.setAttribute("userId", userId);
		rd.forward(request, response);
	}

	private void editShoppingCartItem(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("product/buy.jsp");
		int userId = Integer.parseInt(request.getParameter("userId"));
		int product = 0;
		int cart = 0;
		// ��������� ��� ������� �������
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select id from shoppingCarts where `user`=?");) {
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				cart = rs.getInt(1);
			} else {
				PreparedStatement ps1 = conn
						.prepareStatement("insert into shoppingCarts(`user`,createdDate) values(?,?)");
				java.sql.Date createdDate = java.sql.Date.valueOf(LocalDate.now());
				ps1.setInt(1, userId);
				ps1.setDate(2, createdDate);
				ps1.executeUpdate();
				ps1.clearParameters();
				ps1 = conn.prepareStatement("select id from shoppingCarts where `user`=?");
				ps1.setInt(1, userId);
				rs = ps1.executeQuery();
				if (rs.next())
					cart = rs.getInt(1);
			}
		}
		int shopCartItemId = Integer.parseInt(request.getParameter("shopCartItemId"));
		// shopItem
		ShoppingCartDetail d = null;
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn
					.prepareStatement("SELECT scd.id,scd.shoppingCart,scd.product,scd.amount,scd.price, p.`name`,"
							+ "p.description,p.price,p.image,p.units,p.country,p.category "
							+ "FROM ShoppingCartDetails scd JOIN Products p on "
							+ "p.id=scd.product where ShoppingCart = ?");
			ps.setInt(1, cart);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Product p = new Product(rs.getInt(3), rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getString(9), rs.getInt(10), rs.getInt(11), rs.getInt(12));
				d = new ShoppingCartDetail(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), p, rs.getDouble(5));
			}

		}
		product = d.getProdyct().getId();
		// shoppingCartId
		Product pr = null;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select * from products where id=?");) {
			ps.setInt(1, product);
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				pr = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8));
			rs.close();

		}
		request.setAttribute("shopItem", d);
		request.setAttribute("shoppingCartId", cart);
		request.setAttribute("product", pr);
		request.setAttribute("userId", userId);
		rd.forward(request, response);
	}

	private void removeFromShoppingCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		try (Connection conn = JDBCUtils.getConnection()) {
			PreparedStatement ps = conn.prepareStatement("delete from shoppingCartDetails where id=?");
			ps.setInt(1, Integer.parseInt(request.getParameter("shopCartItemId")));
			ps.executeUpdate();
		}
		RequestDispatcher rd = request.getRequestDispatcher("showUserShoppingCart");
		rd.forward(request, response);
	}

	private void updateShoppingCartItem(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		Product p = null;
		ShoppingCartDetail d = null;
		try (Connection conn = JDBCUtils.getConnection()) {
			PreparedStatement ps = conn
					.prepareStatement("SELECT scd.id,scd.shoppingCart,scd.product,scd.amount,scd.price, p.`name`,"
							+ "p.description,p.price,p.image,p.units,p.country,p.category "
							+ "FROM ShoppingCartDetails scd JOIN Products p on " + "p.id=scd.product where scd.id = ?");
			ps.setInt(1, Integer.parseInt(request.getParameter("shopCartDetailId")));
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				p = new Product(rs.getInt(3), rs.getString(6), rs.getString(7), rs.getDouble(8), rs.getString(9),
						rs.getInt(10), rs.getInt(11), rs.getInt(12));
				d = new ShoppingCartDetail(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), p, rs.getDouble(5));
			}
			rs.close();
			int amount = Integer.parseInt(request.getParameter("amount"));
			if (amount <= 0)
				throw new Exception("���� ������� �������� ��������");
			if (amount > p.getUnits())
				throw new Exception("������������ ������");
			double price = amount * p.getPrice();
			ps.clearParameters();
			ps.close();
			ps = conn.prepareStatement("update shoppingCartDetails set amount=?,price=? where id=?;");
			ps.setInt(1, amount);
			ps.setDouble(2, price);
			ps.setInt(3, Integer.parseInt(request.getParameter("shopCartDetailId")));
			ps.executeUpdate();
			request.setAttribute("messag", "���������� ������� ���� ���������");
			request.setAttribute("messagColor", "green");
		} catch (Exception e) {
			request.setAttribute("messag", "�� ������� �������� �������: " + e.getMessage());
			request.setAttribute("messagColor", "red");
		}
		RequestDispatcher rd = request.getRequestDispatcher("showUserShoppingCart");
		rd.forward(request, response);
	}

	private void insertShoppingCartItem(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("product/buy.jsp");
		int product = Integer.parseInt(request.getParameter("prodId"));
		int userId = Integer.parseInt(request.getParameter("userId"));
		int cart = Integer.parseInt(request.getParameter("shoppingCart"));
		// shoppingCart
		// ��������� ��� ������� �������

		// shoppingCartId
		Product pr = null;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("select * from products where id=?");) {
			ps.setInt(1, product);
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				pr = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8));
			rs.close();

		}

		try (Connection conn = JDBCUtils.getConnection();) {
			int amount = Integer.parseInt(request.getParameter("amount"));
			PreparedStatement ps = conn
					.prepareStatement("select * from shoppingCartDetails where product=? and shoppingcart=?");
			ps.setInt(1, product);
			ps.setInt(2, cart);
			ResultSet rs = ps.executeQuery();
			boolean res = rs.next();
			rs.close();
			if (amount <= 0)
				throw new Exception("���� ������� �������� ��������");
			if (res) {
				ps.clearParameters();
				ps = conn.prepareStatement(
						"select id,amount from shoppingCartDetails where product=? and shoppingcart=?");
				ps.setInt(1, product);
				ps.setInt(2, cart);
				rs = ps.executeQuery();
				int detailId = 0;
				int existingAmount = 0;
				if (rs.next()) {
					detailId = rs.getInt(1);
					existingAmount = rs.getInt(2);
				}
				rs.close();
				amount = existingAmount + amount;
				if (amount > pr.getUnits())
					throw new Exception("������������ ������");
				double price = amount * pr.getPrice();
				ps.clearParameters();
				ps = conn.prepareStatement("update shoppingCartDetails set amount=?,price=? where id=? ");
				ps.setInt(1, amount);
				ps.setDouble(2, price);
				ps.setInt(3, detailId);
				ps.executeUpdate();
			} else {
				if (amount > pr.getUnits())
					throw new Exception("������������ ������");
				double price = amount * pr.getPrice();
				ps.clearParameters();
				ps.close();
				ps = conn.prepareStatement(
						"insert into shoppingCartDetails(shoppingCart,product,amount,price) values(?,?,?,?)");
				ps.setInt(1, cart);
				ps.setInt(2, product);
				ps.setInt(3, amount);
				ps.setDouble(4, price);
				ps.executeUpdate();

			}
			request.setAttribute("message", "����� ��� �������� � �������");
			request.setAttribute("messageColor", "green");
		} catch (Exception e) {
			request.setAttribute("message", "�� ������� �������� ����� � �������: " + e.getMessage());
			request.setAttribute("messageColor", "red");
		}

		request.setAttribute("shoppingCartId", cart);
		request.setAttribute("product", pr);
		request.setAttribute("userId", userId);
		rd.forward(request, response);
	}

	private void toOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("showUserShoppingCart");
		int cartId = Integer.parseInt(request.getParameter("cartId"));
		int userId = Integer.parseInt(request.getParameter("userId"));
		int orderId = 0;
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn
					.prepareStatement("SELECT scd.id,scd.shoppingCart,scd.product,scd.amount,scd.price, p.`name`,"
							+ "p.description,p.price,p.image,p.units,p.country,p.category "
							+ "FROM ShoppingCartDetails scd JOIN Products p on "
							+ "p.id=scd.product where ShoppingCart = ?");
			ps.setInt(1, cartId);
			ResultSet rs = ps.executeQuery();
			List<ShoppingCartDetail> shopCartDetails = new ArrayList<>();
			while (rs.next()) {
				Product p = new Product(rs.getInt(3), rs.getString(6), rs.getString(7), rs.getDouble(8),
						rs.getString(9), rs.getInt(10), rs.getInt(11), rs.getInt(12));
				ShoppingCartDetail d = new ShoppingCartDetail(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), p,
						rs.getDouble(5));
				shopCartDetails.add(d);
			}
			rs.close();
			for (ShoppingCartDetail scd : shopCartDetails) {
				if (scd.getProdyct().getUnits() < scd.getAmount())
					throw new Exception("������������� ���������� �� ������");
			}
			ps = conn.prepareStatement("insert into orders(`user`,orderdate) values(?,?);");
			ps.setInt(1, userId);
			ps.setDate(2, java.sql.Date.valueOf(LocalDate.now()));
			ps.executeUpdate();
			ps = conn.prepareStatement("select last_insert_id()");
			rs = ps.executeQuery();
			if (rs.next())
				orderId = rs.getInt(1);
			rs.close();
			ps.clearParameters();
			ps = conn.prepareStatement("update products set units=? where id=?");
			for (ShoppingCartDetail scd : shopCartDetails) {
				int units = scd.getProdyct().getUnits() - scd.getAmount();
				ps.setInt(1, units);
				ps.setInt(2, scd.getProductId());
				ps.executeUpdate();
			}
			ps.clearParameters();
			ps = conn.prepareStatement("insert into orderDetails(orderId,product,amount,price) values(?,?,?,?)");
			for (ShoppingCartDetail scd : shopCartDetails) {
				ps.setInt(1, orderId);
				ps.setInt(2, scd.getProductId());
				ps.setInt(3, scd.getAmount());
				ps.setDouble(4, scd.getPrice());
				ps.executeUpdate();
			}
			ps.clearParameters();
			ps = conn.prepareStatement("delete from shoppingCartDetails where shoppingCart=?");
			ps.setInt(1, cartId);
			ps.executeUpdate();
			request.setAttribute("messag", "����� ��� ��������");
			request.setAttribute("messagColor", "green");
		} catch (Exception ex) {
			request.setAttribute("messag", "����� �� ��� ��������:" + ex.getMessage());
			request.setAttribute("messagColor", "red");
		}
		rd.forward(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		String action = request.getServletPath();
		switch (action) {
		case "/showUserShoppingCart":
			try {
				showUserShoppingCart(request, response);
			} catch (ServletException | IOException | SQLException e4) {
				// TODO Auto-generated catch block
				e4.printStackTrace();
			}
			break;
		case "/toOrder":
			try {
				toOrder(request, response);
			} catch (ServletException | IOException | SQLException e5) {
				// TODO Auto-generated catch block
				e5.printStackTrace();
			}
			break;
		case "/addToShoppingCart":
			try {
				addToShoppingCart(request, response);
			} catch (ServletException | IOException | SQLException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
			break;
		case "/editShoppingCartItem":
			try {
				editShoppingCartItem(request, response);
			} catch (ServletException | IOException | SQLException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
			break;
		case "/insertShoppingCartItem":
			try {
				insertShoppingCartItem(request, response);
			} catch (ServletException | IOException | SQLException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
			break;
		case "/updateShoppingCartItem":
			try {
				updateShoppingCartItem(request, response);
			} catch (ServletException | IOException | SQLException e4) {
				// TODO Auto-generated catch block
				e4.printStackTrace();
			}
			break;
		case "/removeFromShoppingCart":
			try {
				removeFromShoppingCart(request, response);
			} catch (ServletException | IOException | SQLException e3) {
				// TODO Auto-generated catch block
				e3.printStackTrace();
			}
			break;
		case "/newCountry":
			try {
				showNewCountryForm(request, response);
			} catch (ServletException | IOException | SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			break;
		case "/editCountry":
			try {
				showEditCountryForm(request, response);
			} catch (ServletException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case "/insertCountry":
			try {
				insertCountry(request, response);
			} catch (ServletException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case "/updateCountry":
			try {
				updateCountry(request, response);
			} catch (ServletException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case "/deleteCountry":
			try {
				deleteCountry(request, response);
			} catch (ServletException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case "/adminPanel":
			try {
				adminPanelList(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/newCategory":
			try {
				showNewCategoryForm(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/editCategory":
			try {
				showEditCategoryForm(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/deleteCategory":
			try {
				deleteCategory(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/insertCategory":
			try {
				insertCategory(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/updateCategory":
			try {
				updateCategory(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/newProduct":
			try {
				showNewProductForm(request, response);
			} catch (ServletException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case "/editProduct":
			try {
				showEditProductForm(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/deleteProduct":
			try {
				deleteProduct(request, response);
			} catch (ServletException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case "/insertProduct":
			try {
				insertProduct(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/updateProduct":
			try {
				updateProduct(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/listProducts":
			try {
				listProducts(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/newOrder":
			try {
				showNewOrderForm(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/editOrder":
			try {
				showEditOrderForm(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/updateOrder":
			try {
				updateOrder(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/insertOrder":
			try {
				insertOrder(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/deleteOrder":
			try {
				deleteOrder(request, response);
			} catch (ServletException | IOException | SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		case "/newOrderDetail":
			try {
				showNewOrderDetailForm(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/editOrderDetail":
			try {
				showEditOrderDetailForm(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/insertOrderDetail":
			try {
				insertOrderDetail(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/updateOrderDetail":
			try {
				updateOrderDetail(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/deleteOrderDetail":
			try {
				deleteOrderDetail(request, response);
			} catch (ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default:
			RequestDispatcher rd = request.getRequestDispatcher("login/login-form.jsp");
			rd.forward(request, response);
			break;
		}
	}

	private void showNewOrderDetailForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("orderDetail/orderDetail.jsp");
		// productList
		// orderList
		List<Order> orders = new ArrayList<>();
		List<Product> products = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("select id from orders");
			ResultSet rs = ps.executeQuery();
			while (rs.next())
				orders.add(new Order(rs.getInt(1)));
			rs.close();
			ps = conn.prepareStatement("select id,`name` from products");
			rs = ps.executeQuery();
			while (rs.next())
				products.add(new Product(rs.getInt(1), rs.getString(2)));
		}
		request.setAttribute("orderList", orders);
		request.setAttribute("productList", products);
		rd.forward(request, response);
	}

	private void showEditOrderDetailForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("orderDetail/orderDetail.jsp");
		// productList
		// orderList
		List<Order> orders = new ArrayList<>();
		List<Product> products = new ArrayList<>();
		OrderDetail detail = null;
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("select id from orders");
			ResultSet rs = ps.executeQuery();
			while (rs.next())
				orders.add(new Order(rs.getInt(1)));
			rs.close();
			ps = conn.prepareStatement("select id,`name` from products");
			rs = ps.executeQuery();
			while (rs.next())
				products.add(new Product(rs.getInt(1), rs.getString(2)));
			rs.close();
			ps = conn.prepareStatement("select * from orderdetails where id=?");
			ps.setInt(1, Integer.parseInt(request.getParameter("id")));
			rs = ps.executeQuery();
			if (rs.next())
				detail = new OrderDetail(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getDouble(5));
		}
		request.setAttribute("orderList", orders);
		request.setAttribute("productList", products);
		request.setAttribute("orderDetail", detail);
		rd.forward(request, response);
	}

	private void showNewProductForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("product/product-form.jsp");
		List<Country> countries = countryDao.selectCountries();
		List<Category> categories = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM Categories;");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				categories.add(new Category(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM Products where id=?;");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				categories.add(new Category(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("countries", countries);
		request.setAttribute("categories", categories);
		rd.forward(request, response);
	}

	private void showEditProductForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		RequestDispatcher rd = request.getRequestDispatcher("product/product-form.jsp");
		List<Country> countries = countryDao.selectCountries();
		List<Category> categories = new ArrayList<>();
		Product prod = null;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT p.id,p.`name`," + "p.description,p.price,p.image,"
						+ "p.units,p.country,p.category,c.`name`,ct.`name`" + " FROM Products p join Categories c "
						+ "on c.id=p.category " + "join Countries ct on ct.id=p.country where p.id=?");) {
			ps.setInt(1, Integer.parseInt(request.getParameter("id")));
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {

				prod = new Product(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5),
						rs.getInt(6), rs.getInt(7), rs.getInt(8), new Category(rs.getInt(7), rs.getString(9)),
						new Country(rs.getInt(7), rs.getString(10)));
			}
			rs.close();
		}
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("SELECT * FROM Categories;");) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				categories.add(new Category(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("product", prod);
		request.setAttribute("countries", countries);
		request.setAttribute("categories", categories);
		rd.forward(request, response);
	}

	private void insertProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int countryId = Integer.parseInt(request.getParameter("country"));
		int categoryId = Integer.parseInt(request.getParameter("category"));
		Country country = countryDao.selectCountry(countryId);
		Category category = categoryDao.selectCategory(categoryId);
		String name = request.getParameter("name");
		String description = request.getParameter("description");
		String image = request.getParameter("image");
		int units = Integer.parseInt(request.getParameter("units"));
		double price = Double.parseDouble(request.getParameter("price"));
		Product prod = new Product(name, description, price, image, units, countryId, categoryId, category, country);
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn
						.prepareStatement("insert into Products" + "(`name`,`description`,price,image,"
								+ "units,country,category)" + " values (?,?,?,?,?,?,?)");) {
			ps.setString(1, prod.getName());
			ps.setString(2, prod.getDescription());
			ps.setDouble(3, prod.getPrice());
			ps.setString(4, image);
			ps.setInt(5, units);
			ps.setInt(6, countryId);
			ps.setInt(7, categoryId);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
	}

	private void deleteProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int product = Integer.parseInt(request.getParameter("id"));
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement("DELETE FROM Products WHERE id=?")) {
			ps.setInt(1, product);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
	}

	private void updateProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int productId = Integer.parseInt(request.getParameter("id"));
		int countryId = Integer.parseInt(request.getParameter("country"));
		int categoryId = Integer.parseInt(request.getParameter("category"));
		Country country = countryDao.selectCountry(countryId);
		Category category = categoryDao.selectCategory(categoryId);
		String name = request.getParameter("name");
		String description = request.getParameter("description");
		String image = request.getParameter("image");
		int units = Integer.parseInt(request.getParameter("units"));
		double price = Double.parseDouble(request.getParameter("price"));
		Product prod = new Product(name, description, price, image, units, countryId, categoryId, category, country);
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn
						.prepareStatement("update Products" + " set `name`=?,`description`=?,price=?,image=?,"
								+ "units=?,country=?,category=? where id=?");) {
			ps.setString(1, prod.getName());
			ps.setString(2, prod.getDescription());
			ps.setDouble(3, prod.getPrice());
			ps.setString(4, image);
			ps.setInt(5, units);
			ps.setInt(6, countryId);
			ps.setInt(7, categoryId);
			ps.setInt(8, productId);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
	}

	private void insertCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		Category category = new Category(name);
		categoryDao.insertCategory(category);
		response.sendRedirect("adminPanel");
	}

	private void insertOrderDetail(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int orderId = Integer.parseInt(request.getParameter("order"));
		int productId = Integer.parseInt(request.getParameter("product"));
		int amount = Integer.parseInt(request.getParameter("amount"));
		double price = Double.parseDouble(request.getParameter("price"));
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn
					.prepareStatement("INSERT INTO OrderDetails(orderId,product,amount,price) VALUES (?,?,?,?)");
			ps.setInt(1, orderId);
			ps.setInt(2, productId);
			ps.setInt(3, amount);
			ps.setDouble(4, price);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
	}

	private void updateOrderDetail(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		int orderId = Integer.parseInt(request.getParameter("order"));
		int productId = Integer.parseInt(request.getParameter("product"));
		int amount = Integer.parseInt(request.getParameter("amount"));
		double price = Double.parseDouble(request.getParameter("price"));
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn
					.prepareStatement("UPDATE OrderDetails SET orderId=?,product=?,amount=?,price=? WHERE id=?");
			ps.setInt(1, orderId);
			ps.setInt(2, productId);
			ps.setInt(3, amount);
			ps.setDouble(4, price);
			ps.setInt(5, id);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
	}

	private void deleteOrderDetail(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		int id = Integer.parseInt(request.getParameter("id"));
		try (Connection conn = JDBCUtils.getConnection();) {
			PreparedStatement ps = conn.prepareStatement("DELETE FROM OrderDetails WHERE id=?");
			ps.setInt(1, id);
			ps.executeUpdate();
		}
		response.sendRedirect("adminPanel");
	}

	private void updateCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		Category category = new Category(id, name);
		categoryDao.updateCategory(category);
		response.sendRedirect("adminPanel");
	}

	private void deleteCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		categoryDao.deleteCategory(id);
		response.sendRedirect("adminPanel");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("UTF-8");
		response.setCharacterEncoding("UTF-8");
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
