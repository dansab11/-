package courseWorkDimash.electonicShop.models;

import java.time.LocalDate;

public class Order {
	private int id;
	private int userId;
	private LocalDate orderDate;
	private double totalPrice;
	private User user;
	public Order(int id) {
		super();
		this.id = id;
	}
	public Order(int id, int userId, LocalDate orderDate) {
		super();
		this.id = id;
		this.userId = userId;
		this.orderDate = orderDate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Order(int id, int userId, LocalDate orderDate, double totalPrice, User user) {
		super();
		this.id = id;
		this.userId = userId;
		this.orderDate = orderDate;
		this.totalPrice = totalPrice;
		this.user = user;
	}
	public Order(int userId, LocalDate orderDate, double totalPrice, User user) {
		super();
		this.userId = userId;
		this.orderDate = orderDate;
		this.totalPrice = totalPrice;
		this.user = user;
	}		
	
}
