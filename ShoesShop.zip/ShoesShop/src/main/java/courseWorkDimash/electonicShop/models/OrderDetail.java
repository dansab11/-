package courseWorkDimash.electonicShop.models;

public class OrderDetail {
	public int id;
	public int orderId;
	public int productId;
	public int amount;
	public double price;
	public Product product;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public OrderDetail(int id, int orderId, int productId, int amount, double price, Product product) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.productId = productId;
		this.amount = amount;
		this.price = price;
		this.product = product;
	}

	public OrderDetail(int orderId, int productId, int amount, double price, Product product) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.amount = amount;
		this.price = price;
		this.product = product;
	}

	public OrderDetail(int id, int orderId, int productId, int amount, double price) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.productId = productId;
		this.amount = amount;
		this.price = price;
	}

	public OrderDetail(int orderId, int productId, int amount, double price) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.amount = amount;
		this.price = price;
	}

}
