package courseWorkDimash.electonicShop.models;

public class ShoppingCart {

}
