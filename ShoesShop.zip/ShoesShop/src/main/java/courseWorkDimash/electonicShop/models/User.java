package courseWorkDimash.electonicShop.models;

import java.time.LocalDate;

public class User {
	private int id;
	private String username;
	private String password;
	private String address;
	private String phone;
	private LocalDate birthday;
	private int country;
	private boolean isAdmin;
	public User(int id, String username) {
		super();
		this.id = id;
		this.username = username;
	}
	public boolean isAdmin() {
		return isAdmin;
	}
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public LocalDate getBirthday() {
		return birthday;
	}
	public void setBirthday(LocalDate birthday) {
		this.birthday = birthday;
	}
	public void setCountry(int country) {
		this.country = country;
	}
	public int getCountry() {
		return country;
	}
	public User(int id, String username, String password, String address, String phone, LocalDate birthday, int country,
			boolean isAdmin) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.address = address;
		this.phone = phone;
		this.birthday = birthday;
		this.country = country;
		this.isAdmin = isAdmin;
	}
	public User(String username, String password, String address, String phone, LocalDate birthday, int country,
			boolean isAdmin) {
		super();
		this.username = username;
		this.password = password;
		this.address = address;
		this.phone = phone;
		this.birthday = birthday;
		this.country = country;
		this.isAdmin = isAdmin;
	}
	
	
	
}
