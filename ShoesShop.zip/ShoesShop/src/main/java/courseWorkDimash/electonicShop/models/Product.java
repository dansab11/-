package courseWorkDimash.electonicShop.models;

public class Product {
	private int id;
	private String name;
	private String description;
	private double price;
	private String image;
	private int units;
	private int countryId;
	private int categoryId;
	private Category category;
	private Country country;

	public Product(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Product(int id, String name, String description, double price, String image, int units, int countryId,
			int categoryId) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.image = image;
		this.units = units;
		this.countryId = countryId;
		this.categoryId = categoryId;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

	public int getCountryId() {
		return countryId;
	}

	public void setCountryId(int countryId) {
		this.countryId = countryId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Product(int id, String name, String description, double price, String image, int units, int countryId,
			int categoryId, Category category, Country country) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.price = price;
		this.image = image;
		this.units = units;
		this.countryId = countryId;
		this.categoryId = categoryId;
		this.category = category;
		this.country = country;
	}

	public Product(String name, String description, double price, String image, int units, int countryId,
			int categoryId, Category category, Country country) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
		this.image = image;
		this.units = units;
		this.countryId = countryId;
		this.categoryId = categoryId;
		this.category = category;
		this.country = country;
	}

}
