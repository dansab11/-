package courseWorkDimash.electonicShop.models;

public class ShoppingCartDetail {
	private int id;
	private int shoppingCart;
	private int productId;
	private int amount;
	private Product prodyct;
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getShoppingCart() {
		return shoppingCart;
	}
	public void setShoppingCart(int shoppingCart) {
		this.shoppingCart = shoppingCart;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Product getProdyct() {
		return prodyct;
	}
	public void setProdyct(Product prodyct) {
		this.prodyct = prodyct;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public ShoppingCartDetail(int id, int shoppingCart, int productId, int amount, Product prodyct, double price) {
		super();
		this.id = id;
		this.shoppingCart = shoppingCart;
		this.productId = productId;
		this.amount = amount;
		this.prodyct = prodyct;
		this.price = price;
	}
	public ShoppingCartDetail(int shoppingCart, int productId, int amount, Product prodyct, double price) {
		super();
		this.shoppingCart = shoppingCart;
		this.productId = productId;
		this.amount = amount;
		this.prodyct = prodyct;
		this.price = price;
	}
	

	

}
