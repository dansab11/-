package courseWorkDimash.electonicShop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import courseWorkDimash.electronicShop.utils.JDBCUtils;
import courseWorkDimash.electonicShop.models.User;

public class UserDao {
	private String insertUser = "insert into Users(username,`password`,address,phone,birthday,country,isAdmin) values(?,?,?,?,?,?,?)";

	public int register(User user) throws SQLException {
		int result = 0;
		try (Connection conn = JDBCUtils.getConnection(); PreparedStatement ps = conn.prepareStatement(insertUser);) {
			ps.setString(1, user.getUsername());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getAddress());
			ps.setString(4, user.getPhone());
			ps.setDate(5, JDBCUtils.getSqlDate(user.getBirthday()));
			ps.setInt(6, user.getCountry());
			ps.setBoolean(7, user.isAdmin());
			result = ps.executeUpdate();
		}
		return result;
	}
}
