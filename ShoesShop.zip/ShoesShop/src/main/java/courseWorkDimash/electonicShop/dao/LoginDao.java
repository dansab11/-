package courseWorkDimash.electonicShop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import courseWorkDimash.electonicShop.models.LoginBean;
import courseWorkDimash.electronicShop.utils.JDBCUtils;

public class LoginDao {
	private String userValidationQuery = "select * from Users where username =? and `password`=?";

	public boolean validate(LoginBean loginBean) throws SQLException {
		boolean result;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(userValidationQuery);) {
			ps.setString(1, loginBean.getUsername());
			ps.setString(2, loginBean.getPassword());
			ResultSet rs = ps.executeQuery();
			result = rs.next();
		}
		return result;
	}

	public boolean checkIfAdmin(LoginBean loginBean) throws SQLException {
		boolean result = false;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(userValidationQuery);) {
			ps.setString(1, loginBean.getUsername());
			ps.setString(2, loginBean.getPassword());
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				result = rs.getBoolean(8);
		}
		return result;
	}
}
