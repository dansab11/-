package courseWorkDimash.electonicShop.dao;

import java.util.List;

import courseWorkDimash.electonicShop.models.Category;
import courseWorkDimash.electronicShop.utils.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CategoryDao {
	private String insert_category = "insert into Categories(`name`) values(?);";
	private String update_category = "update Categories set `name`=? where id=?;";
	private String deleteCategory = "delete from Categories where id=?;";
	private String selectCategory = "select * from categories;";
	private String select_categories = "select * from categories where id=?";

	public void insertCategory(Category category) {
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(insert_category);) {
			ps.setString(1, category.getName());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean updateCategory(Category category) {
		boolean result = false;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(update_category);) {
			ps.setString(1, category.getName());
			ps.setInt(2, category.getId());
			result = ps.executeUpdate() > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public boolean deleteCategory(int id) {
		boolean result = false;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(deleteCategory);) {
			ps.setInt(1, id);
			result = ps.executeUpdate() > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}

	public List<Category> selectCategories() {
		List<Category> categories = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(select_categories);) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				categories.add(new Category(rs.getInt(1), rs.getString(2)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return categories;
	}

	public Category selectCategory(int id) {
		Category category = null;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(selectCategory);) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				category = new Category(rs.getInt(1), rs.getString(2));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return category;
	}
}
