package courseWorkDimash.electonicShop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;

import courseWorkDimash.electonicShop.models.Country;
import courseWorkDimash.electronicShop.utils.JDBCUtils;

public class CountryDao {
	private String insert_into_countries = "insert into countries(`name`) values(?)";
	private String update_country = "update countries set `name`=? where id=?";
	private String select_all_countries = "select * from countries";
	private String select_country = "select * from countries where id=?";
	private String delete_country = "delete from countries where id=?";

	public void insertCountry(Country country) throws SQLException {
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(insert_into_countries);) {
			ps.setString(1, country.getName());
			ps.executeUpdate();
		}
	}

	public boolean updateCountry(Country country) throws SQLException {
		boolean result;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(update_country);) {
			ps.setString(1, country.getName());
			ps.setInt(2, country.getId());
			result = ps.executeUpdate() > 0;
		}
		return result;
	}

	public List<Country> selectCountries() throws SQLException {
		List<Country> countries = new ArrayList<>();
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(select_all_countries);) {
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				countries.add(new Country(rs.getInt(1), rs.getString(2)));
			}
		}
		return countries;
	}

	public Country selectCountry(int id) throws SQLException {
		Country country = null;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(select_country);) {
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			if (rs.next())
				country = new Country(rs.getInt(1), rs.getString(2));
		}
		return country;
	}

	public boolean deleteCountry(int id) throws SQLException {
		boolean res;
		try (Connection conn = JDBCUtils.getConnection();
				PreparedStatement ps = conn.prepareStatement(delete_country);) {
			ps.setInt(1, id);
			res = ps.executeUpdate() > 0;
		}
		return res;
	}
}
