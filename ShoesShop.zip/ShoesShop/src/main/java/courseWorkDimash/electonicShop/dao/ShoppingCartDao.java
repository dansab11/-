package courseWorkDimash.electonicShop.dao;

public class ShoppingCartDao {

}
