package courseWorkDimash.electronicShop.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;

public class JDBCUtils {
	protected static String JDBCurl = "jdbc:mysql://localhost:3306/shopDatabase";
	protected static String JDBCusername = "root";
	protected static String JDBCpassword = "mysql";

	public static Connection getConnection() throws SQLException {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(JDBCurl, JDBCusername, JDBCpassword);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	public static Date getSqlDate(LocalDate date) {
		return Date.valueOf(date);
	}
}
